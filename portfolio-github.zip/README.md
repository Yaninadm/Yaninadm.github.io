# Yanina Di Marzio — Portfolio

Portfolio en español para empleo y servicios profesionales. Incluye proyectos de administración, datos, diseño, libros, audiovisual, teatro y coaching.

## Verlo

Abrir `dist/index.html` en un navegador. Es un sitio estático: no requiere instalaciones ni claves. Los filtros usan JavaScript y las fichas usan el control nativo `details`.

## GitHub Pages

El botón «Descargar versión para GitHub» del sitio entrega los archivos públicos con `index.html` en la raíz, listos para subir a un repositorio. La cuenta de GitHub debe crearse y verificarse por su titular antes de subirlos.

Para publicar en GitHub Pages: subir el contenido descomprimido al repositorio, abrir Settings → Pages y seleccionar la publicación desde la rama principal y la carpeta raíz. No subir `.openai`, credenciales ni datos de clientes.

## Contenido y edición

Editar texto y fichas en `dist/index.html`, estilos en `dist/styles.css` y filtros en `dist/app.js`. Las muestras están en `dist/assets`.

Las fichas distinguen experiencia, muestras ficticias y proyectos en desarrollo. Las imágenes administrativas son muestras ilustrativas del portfolio previo. El dashboard se describe como proyecto en desarrollo y no incluye datos de matriculados. El chatbot es una propuesta con guion, no un servicio operativo. No hay formulario que almacene información.

Las imágenes y textos corresponden a materiales de Yanina Di Marzio y trabajo asistido. No se aplica una licencia abierta a los diseños, libros ni marcas de terceros. La atribución de la obra teatral corresponde a Claudia Piñeiro. No se afirma vínculo comercial oficial con Cielo Razzo.

El sitio usa fuentes de Google con fallback local. El contacto abre el correo del visitante. Actualizado al 29 de septiembre de 2026.
